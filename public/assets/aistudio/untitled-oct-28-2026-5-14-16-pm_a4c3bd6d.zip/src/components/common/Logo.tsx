import React from 'react';

interface LogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
  className?: string;
  isLight?: boolean;
  animated?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showSubtitle = true,
  className = '',
  isLight = false,
  animated = false
}) => {
  const iconSizes = {
    xs: 'w-6 h-6',
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24'
  };

  const textSizes = {
    xs: 'text-sm',
    sm: 'text-base font-black',
    md: 'text-xl font-black',
    lg: 'text-3xl font-black',
    xl: 'text-4xl font-black'
  };

  const subSizes = {
    xs: 'text-[8px]',
    sm: 'text-[9px]',
    md: 'text-[10px]',
    lg: 'text-xs',
    xl: 'text-sm font-semibold'
  };

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Brand Emblem: Authentic Sky-Blue Kid Mascot with Crown Cloud & Golden Star */}
      <div
        className={`${iconSizes[size]} relative flex items-center justify-center rounded-2xl shadow-sm bg-gradient-to-tr from-[#00B8F5] via-[#38BDF8] to-[#67E8F9] p-1.5 transition-transform duration-300 ${
          animated ? 'animate-bounce-cart' : 'hover:scale-105'
        }`}
      >
        <svg
          viewBox="0 0 56 56"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-sm"
        >
          {/* Cloud Body with soft contours */}
          <path
            d="M17 40H39C43.9706 40 48 35.9706 48 31C48 26.3 44.4 22.4 39.8 22.05C39.4 14.3 33.1 8 25.2 8C18.4 8 12.8 12.4 11 18.6C6.5 19.5 3 23.4 3 28C3 33.5228 7.47715 38 13 38L17 40Z"
            fill="white"
            fillOpacity="0.98"
          />

          {/* Cute Little Golden Crown on top of cloud */}
          <path
            d="M20 13L24 18L28 12L32 18L36 13L35 22H21L20 13Z"
            fill="#FFD76A"
          />
          <circle cx="28" cy="11" r="1.5" fill="#FF4FA3" />

          {/* Happy cute face details */}
          <circle cx="20" cy="27" r="2" fill="#0096C7" />
          <circle cx="32" cy="27" r="2" fill="#0096C7" />
          {/* Smiling mouth */}
          <path
            d="M23 31C24.5 33 27.5 33 29 31"
            stroke="#0096C7"
            strokeWidth="2"
            strokeLinecap="round"
          />
          {/* Cheerful Pink Cheeks */}
          <ellipse cx="17" cy="29" rx="2.5" ry="1.5" fill="#FF4FA3" fillOpacity="0.5" />
          <ellipse cx="35" cy="29" rx="2.5" ry="1.5" fill="#FF4FA3" fillOpacity="0.5" />

          {/* Sparkles */}
          <path
            d="M44 14L45.5 18L49.5 19.5L45.5 21L44 25L42.5 21L38.5 19.5L42.5 18L44 14Z"
            fill="#FFD76A"
          />
        </svg>
      </div>

      {/* Brand Typography */}
      <div className="flex flex-col justify-center leading-none">
        <div className="flex items-center">
          <span
            className={`tracking-tight ${textSizes[size]} ${
              isLight ? 'text-white' : 'text-[#0096C7]'
            }`}
            style={{ fontFamily: "'Quicksand', 'Plus Jakarta Sans', sans-serif" }}
          >
            MITTI<span className="text-[#00B8F5]">VOY</span>
          </span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#FF4FA3] ml-1 mb-1 animate-pulse" />
        </div>
        {showSubtitle && (
          <span
            className={`tracking-widest uppercase mt-0.5 ${subSizes[size]} ${
              isLight ? 'text-sky-100 font-bold' : 'text-slate-500 font-bold'
            }`}
          >
            Bolalar kiyimlari
          </span>
        )}
      </div>
    </div>
  );
};
